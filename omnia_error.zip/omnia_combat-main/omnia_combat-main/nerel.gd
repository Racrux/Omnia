extends CharacterBody2D
# const PlayerAttackAnimation = preload("res://scenes/Nerel_Battle.tscn")

@onready var animation_tree =$AnimationTree
@onready var state_machine = animation_tree.get("parameters/playback")

@onready var animation_player = $AnimationPlayer
# add attack button 
# @onready var attack_button = $AttackButton
# add progress bar to indicate health condition
# @onready var progress_bar = $progress_bar
# health should be connected to some variable (hard coded for now).
@onready var MAX_HEALTH: float = 5

@onready var auto_attack_timer = $AutoAttackTimer


var health: float = 5:
	set(value):
		health = value
		# some type of health bar to indicate the Player's health
		# _update_progess_bar()
		# player hurt animation when it gets hit by an enemy
		#_play_animation()

# function to update the player's health bar
# func _update_progress_bar():
	# progress_bar.value = (health / MAX_HEALTH) * 100

# function to update player animation when it hurts
# func _play_animation_hurt():
	# animation_player.play("hurt")

# function to update player animation when it attacks
# func _play_animation_attack():
	# animation_player.play("attack")


# function to update player animation when it uses skill
# func _play_animation_skill():
	# animation_player.play("skill")

# Attack and Auto_attack is different animation track, so keep in track.
var is_attacking = false
var is_auto_attacking = false

func take_damage(value):
	health =- value


# main init
func _ready():
	animation_tree.active = true  
	animation_tree.set("parameters/playback", "idle")  # idle at start
	state_machine.travel("idle")  


func _process(delta: float) -> void:
	# auto_attack w/out condition 

	# manual attack condition
	if Input.is_action_just_pressed("attack"):
			print("manual attack pressed")
			_play_attack()


func _play_attack():
	if is_attacking:
		print("Attack intercepted auto_attack!")

	is_attacking = true
	animation_tree.active = false
	animation_player.play("attack")
	# wait til attack finishes, and set back to the original state (idle)
	await animation_player.animation_finished
	animation_tree.active = true
	is_attacking = false

func _play_auto_attack():
	if is_auto_attacking or is_attacking:
		return

	is_auto_attacking = true
	animation_tree.active = false
	animation_player.play("auto_attack")
	print("auto_attack started")
	# wait til attack finishes, and set back to the original state (idle)
	await animation_player.animation_finished
	animation_tree.active = true
	is_auto_attacking = false
	print("auto_attack finished")

# auto_attack implemention w/ timer node
func _on_auto_attack_timer_timeout() -> void:
	if(is_attacking):
		print("auto_attack delayed due to manual attack")
		return

	print("Auto Attacking")
	_play_auto_attack()
