extends AnimatedSprite2D

func _ready():
	print("Press P to play animation")  # Prints a message once when the scene starts

func _process(delta):
	# Check if the "play_animation" action is pressed
	if Input.is_action_just_pressed("play_animation"):
		print("Play animation pressed!")
		play("attack")  # Play the "attack" animation
